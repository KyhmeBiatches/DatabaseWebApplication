USE SurveySystem;

INSERT dbo.SurveyAdmin(name, user_name, password, email)
	VALUES('UCN Canteen', 'UCNCanteen', '123456', 'ucncanteen@ucn.dk')
GO

INSERT dbo.Survey(status, title, admin_id)
	VALUES(1, 'Canteen suervey', 1)
GO
INSERT dbo.QuestionTrigger(answer, jump_to)
	VALUES(0, 8),
	(0, 10),
	(0, 2)
GO

INSERT dbo.QuestionType(typename)
	VALUES('BoolAnswer'),
	('PrefabAnswer'),
	('TextAnswer')
GO

INSERT dbo.QuestionSettings(a_amount, question_type, trigger_id)
	VALUES(1, 1, null),
	(1, 2, null),
	(10, 2, null),
	(1, 3, null),
	(1, 1, 2)
GO

INSERT dbo.Question(text, number, survey_id, question_settings_id)
	VALUES('Do you like the Canteen?', 1, 1, 1),
	('Is it to expensive?', 2, 1, 1),
	('Should we chance it?', 3, 1, 1),
	('How would you rate the food?', 4, 1, 2),
	('How would you rate the quality?', 5, 1, 2),
	('What dishes do you like we have?', 6, 1, 3),
	('Any notes?', 7, 1, 4),
	('Should we have cola?', 8, 1, 5),
	('Why should we have cola?', 9, 1, 4),
	('What would you buy the most?', 10, 1, 4)

GO

INSERT dbo.PrefabAnswers(text, question_id)
	VALUES('1', 4),
	('2', 4),
	('3', 4),
	('4', 4),
	('5', 4),
	('1', 5),
	('2', 5),
	('3', 5),
	('4', 5),
	('5', 5),
	('Morgenmad', 6),
	('Sausage rolls', 6),
	('Hot dishes with pork', 6),
	('Hot dishes with beef', 6),
	('Hot dishes with fish', 6),
	('Slad', 6)
GO


