USE Master;
GO
ALTER DATABASE [SurveySystem] SET SINGLE_USER WITH ROLLBACK IMMEDIATE 
GO
IF EXISTS(SELECT * from sys.databases WHERE name='SurveySystem')
BEGIN
    DROP DATABASE SurveySystem;
END

CREATE DATABASE SurveySystem;

GO
USE SurveySystem;

CREATE TABLE SurveyAdmin(
	id int IDENTITY(1,1) PRIMARY KEY,
	name varchar(75) NOT NULL,
	user_name varchar(20) NOT NULL,
	password varchar(30) NOT NULL,
	email varchar(50)
)

CREATE TABLE Survey(
	id int IDENTITY(1,1) PRIMARY KEY,
	status int NOT NULL,
	title varchar(100) NOT NULL,
	admin_id int FOREIGN KEY REFERENCES SurveyAdmin(id) NOT NULL
)

CREATE TABLE SurveyUser(
	id int IDENTITY(1,1) PRIMARY KEY,
	isMale bit,
	age int,
	email varchar(50),
	marital_status varchar(30)
)

CREATE TABLE Rating(
	rating int NOT NULL,
	user_id int FOREIGN KEY REFERENCES SurveyUser(id) NOT NULL,
	survey_id int FOREIGN KEY REFERENCES Survey(id) NOT NULL
)

CREATE TABLE QuestionTrigger(
	id int IDENTITY(1,1) PRIMARY KEY,
	answer bit NOT NULL,
	jump_to int NOT NULL
)

CREATE TABLE QuestionType(
	id int IDENTITY(1,1) PRIMARY KEY,
	typename varchar(50)
)

CREATE TABLE QuestionSettings(
	id int IDENTITY(1,1) PRIMARY KEY,
	a_amount int NOT NULL,
	question_type int FOREIGN KEY REFERENCES QuestionType(id) NOT NULL,
	trigger_id int FOREIGN KEY REFERENCES QuestionTrigger(id)
)

CREATE TABLE Question(
	id int IDENTITY(1,1) PRIMARY KEY,
	text varchar(255) NOT NULL,
	number int NOT NULL,
	survey_id int FOREIGN KEY REFERENCES Survey(id) NOT NULL,
	question_settings_id int FOREIGN KEY REFERENCES QuestionSettings(id) NOT NULL
)

CREATE TABLE PrefabAnswers(
	id int IDENTITY(1,1) PRIMARY KEY,
	text varchar(255) NOT NULL,
	question_id int FOREIGN KEY REFERENCES Question(id) NOT NULL
)

CREATE TABLE Answer(
	id int IDENTITY(1,1) PRIMARY KEY,
	bool_a bit,
	answer varchar(255),
	prefab_answer int FOREIGN KEY REFERENCES PrefabAnswers(id),
	survey_id int FOREIGN KEY REFERENCES Survey(id) NOT NULL,
	question_id int FOREIGN KEY REFERENCES Question(id) NOT NULL,
	user_id int FOREIGN KEY REFERENCES SurveyUser(id)
)
