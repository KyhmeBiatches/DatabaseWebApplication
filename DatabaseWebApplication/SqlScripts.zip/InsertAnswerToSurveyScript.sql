USE SurveySystem;

INSERT dbo.SurveyUser(isMale, age, email, marital_status)
	VALUES(0, 21, 'ucnstudent@ucn.dk', null)
GO

INSERT dbo.Answer(bool_a, answer, prefab_answer, survey_id, question_id, user_id)
	VALUES(0, null, null, 1, 1, 1),
	(1, null, null, 1, 2, 1),
	(1, null, null, 1, 3, 1),
	(null, null, 2, 1, 4, 1),
	(null, null, 7, 1, 5, 1),
	(null, null, 11, 1, 6, 1),
	(null, null, 12, 1, 6, 1),
	(null, 'So much to improve', null, 1, 7, 1),
	(1, null, null, 1, 8, 1),
	(null, 'Cola is awesome!', null, 1, 9, 1),
	(null, 'It all, it it where good', null, 1, 10, 1)

GO