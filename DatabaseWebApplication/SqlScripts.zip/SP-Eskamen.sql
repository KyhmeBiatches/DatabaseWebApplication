USE SurveySystem

GO -- Create proc needs to be the first thing called, thats why we use the statement GO
CREATE PROC spGetQuestionsBySurveyId
(
	@surveyId INT
)
AS
BEGIN
SELECT q.id, q.number, q.question_settings_id, q.survey_id, q.text
FROM Question as q
WHERE q.survey_id = @surveyId
END


GO
CREATE PROC spGetAnswersByUserId
(
	@userId int
)
AS
BEGIN
SELECT a.id, a.prefab_answer, a.question_id, a.survey_id, a.user_id, a.bool_a
FROM Answer a
	WHERE a.user_id = @userId
END


GO


-- Get all answers and questions by survey

CREATE PROC spGetAnswersWithQuestionsBySurvey
(
	@surveyId int
)
AS

BEGIN 

SELECT a.answer, a.bool_a, q.number, q.text
FROM Answer a
	INNER JOIN Question q
	ON q.id = a.question_id
WHERE a.survey_id = @surveyId
END



-- Insert an answer
GO
CREATE PROC spCreateAnswerToBoolQuestion
(
	@QuestionId int,
	@bool bit,
	@userId int,
	@surveyId int
)
AS
BEGIN

INSERT INTO Answer (bool_a, question_id, survey_id, user_id)
VALUES (@bool, @questionId, @surveyId, @userId)

END




GO 

-- Update suerveyStatus to ready
CREATE PROC spUpdateSurveyStatusToReady
(
	@surveyId int
)
AS
BEGIN
UPDATE Survey
SET status = 1
WHERE Survey.id = @surveyId
END


GO



-- Delete survey and everthing asosiated
CREATE PROC spDeleteSurveyAndEverythingWithIt
(
	@surveyId int
)
AS
BEGIN

DELETE FROM PrefabAnswers
WHERE PrefabAnswers.question_id IN
(
    SELECT Question.id
	FROM Question
	WHERE Question.survey_id = @surveyId
)

DELETE FROM Rating
WHERE rating.survey_id = @surveyId

DELETE FROM SurveyUser
WHERE SurveyUser.id IN 
(
	SELECT Rating.user_id
	FROM Rating
	WHERE Rating.survey_id = @surveyId
)

DELETE FROM SurveyAdmin 
WHERE SurveyAdmin.id IN
(
	SELECT Survey.admin_id
	FROM Survey
	WHERE Survey.id = @surveyId
)

DELETE FROM Question
WHERE Question.survey_id = @surveyId

DELETE FROM Answer
WHERE survey_id = @surveyId

DELETE FROM Survey
WHERE Survey.id = @surveyId

END
